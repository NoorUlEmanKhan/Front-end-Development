# Fundamentals of Web Development, 2nd Edition
### Chapter 8 [JavaScript 1], Project 1 [Art]
Demonstrate your proficiency with loops, conditionals, arrays, and functions in
JavaScript.

  
