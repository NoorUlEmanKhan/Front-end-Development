/* add loop and other code here ... in this simple exercise we are not
   going to concern ourselves with minimizing globals, etc */

   function calculateTotal(quantity, price) {
      return quantity * price;
    }

document.addEventListener('DOMContentLoaded', function () {
   var subtotal = 0;
   var taxRate = 0.1;
   var shipping = 40;
   var grandTotal = 0;
 
   for (var i = 0; i < data.length; i++) {
     var product = data[i];
     var total = calculateTotal(product.quantity, product.price);
     subtotal += total;
 
     outputCartRow(product.file, product.title, product.quantity, product.price, total);
   }
 
   var tax = subtotal * taxRate;
   if (subtotal > 1000) {
     shipping = 0;
   }
   grandTotal = subtotal + tax + shipping;
 
   document.querySelector('.totals:nth-child(1) td:last-child').textContent = '$' + subtotal.toFixed(2);
   document.querySelector('.totals:nth-child(2) td:last-child').textContent = '$' + tax.toFixed(2);
   document.querySelector('.totals:nth-child(3) td:last-child').textContent = '$' + shipping.toFixed(2);
   document.querySelector('.totals.focus td:last-child').textContent = '$' + grandTotal.toFixed(2);
 });
 