# Fundamentals of Web Development, 2nd Edition
### Chapter 5 [HTML 2], Project 1 [Book CRM]
Edit Chapter05-project01.html and Chapter05-project01.css so the page looks
similar to that shown in Figure 5.32.

The file process.php provided here is unnecessary. As indicated in the end-of-chapter instructions on pages 204-208, it can be accessed via the url:

<http://www.randyconnolly.com/tests/process.php>

The source code for this PHP page have been provided to mainly satisfy your intellectual curiousity; if, for some reason the above URL doesn't work, you can put it on some other PHP-enabled web server and test the submit actions of these three projects.

  
