# Fundamentals of Web Development, 2nd Edition
### Chapter 5 [HTML 2], Project 3 [Travel]
Edit Chapter05-project03.html and Chapter05-project03.css so the page looks
similar to that shown in Figure 5.34.



  
